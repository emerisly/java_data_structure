package stringScanner;

public class Tryout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.printf("%1$1d %3$2s%2$2s ",0,1,"N","NP","==",":","?");
		//System.out.println();
		//System.out.printf("%s==%s","N","NP");
		System.out.printf("%1$1d %2$1c %3$1s",1,'2',"3");
		//System.out.printf("%6$2d %8$2d %1$1c %3$1c %4$1c %7$2c %2$2c %5$1c",1,2,'3','4','5','6','7','8');
	    //System.out.printf("%6$2d %8$2d %1$1c %3$1c %4$1c %7$2c %2$2s %5$1s",0,1,'N','N','P',':',"==","?");
		System.out.println();
		//System.out.printf(78);
	}

}
