package Money;

public class MoneyRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Money mine=new Money(100,946);
		System.out.println(mine);
	}

}
