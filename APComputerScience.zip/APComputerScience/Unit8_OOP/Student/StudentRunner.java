package Student;
public class StudentRunner {
	public static void main(String[] args) {
		Student Emerald=new Student(647647,2021,4.0);
		Emerald.getName().setName("Emerald", "E", "Liu");
		System.out.println(Emerald);
		System.out.println("\n\nHappy New Year Everyone!");
	}
}
