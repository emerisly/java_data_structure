package InstanceMethods;

public class PointRunner {
	
	
	public static void main(String[] args) {
		Point point1=new Point();
		
		point1.translate(1,1);
		System.out.println(point1);
	}
}
