package Test;

public class PointRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NamedPoint p=new NamedPoint(1,1,"hey");
		System.out.println(p);

	}

}
