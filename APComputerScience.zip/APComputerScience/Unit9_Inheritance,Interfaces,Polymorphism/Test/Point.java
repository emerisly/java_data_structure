package Test;

public class Point {
	private int x;
	private int y;
	
	public Point(int a,int b) {
		x=a;
		y=b;
	}
	public String toString() {
		return x+" "+y;
	}
}
