package Polygon;

public interface rightAnglable {
	String getAngle();
}
