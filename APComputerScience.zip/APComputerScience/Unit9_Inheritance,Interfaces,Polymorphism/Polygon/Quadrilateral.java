package Polygon;

public class Quadrilateral extends Polygon{

	public Quadrilateral() {
		super(4);
	}
	public String toString() {
		return super.toString()+" A quadrilateral that have 4 sides.";
	}

}
