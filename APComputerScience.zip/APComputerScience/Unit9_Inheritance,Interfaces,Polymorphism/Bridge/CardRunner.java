package Bridge;

public class CardRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Card c1=new Card(5,3);
		Card c2=new Card(11,1);
		System.out.println(c1);
		System.out.println(c2);
	}

}
