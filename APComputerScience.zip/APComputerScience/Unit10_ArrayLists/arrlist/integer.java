package arrlist;

import java.util.ArrayList;

public class integer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> myInts=new ArrayList<>();
		

	}

}
