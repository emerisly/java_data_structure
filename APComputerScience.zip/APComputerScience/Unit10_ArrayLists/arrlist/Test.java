package arrlist;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> stringList=new ArrayList<String>();
		List<Integer> intList=new ArrayList<Integer>();
		ArrayList<Comparable> compList=new ArrayList<Comparable>();

	}

}
