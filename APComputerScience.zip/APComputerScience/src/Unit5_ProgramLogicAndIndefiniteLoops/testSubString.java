package Unit5_ProgramLogicAndIndefiniteLoops;


public class testSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="okk";
		String s2=s.substring(1,3);
		System.out.println(s2);

	}

}
