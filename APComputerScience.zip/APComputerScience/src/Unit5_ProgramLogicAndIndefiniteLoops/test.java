package Unit5_ProgramLogicAndIndefiniteLoops;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "";
		if(s.length() > 0 && s.charAt(0) == ' ')
		{
		  System.out.println("Starts with a space!");
		}
		System.out.println("All ok!");


	}

}
