package Unit5_ProgramLogicAndIndefiniteLoops;

public class testCharacterClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch='a';
		System.out.println(Character.toUpperCase(ch));
	}

}
