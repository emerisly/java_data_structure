package Unit7_Arrays;

public class InitializeInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
///		n++;
		int m=0;
//		if(n>m) {
//			System.out.println("n>m");
//		}
//		System.out.println(n);
	}

}
