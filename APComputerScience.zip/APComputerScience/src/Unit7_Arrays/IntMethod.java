package Unit7_Arrays;

public class IntMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=0;
		change(num);
		System.out.println(num);
	}

	private static void change(int num) {
		// TODO Auto-generated method stub
		num=2;
	}

}
